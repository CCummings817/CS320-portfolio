package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import main.java.model.Appointment;
import main.java.service.AppointmentService;

import java.util.Calendar;
import java.util.Date;

public class AppointmentServiceTest {

    private static final String VALID_ID = "APPT000001";
    private static final String VALID_DESCRIPTION = "Annual checkup with primary care doctor";

    private AppointmentService service;
    private Appointment appointment;
    private Date futureDate;
    private Date farFutureDate;

    @BeforeEach
    void setUp() {
        // Always 30 days from today -- never stale
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, 30);
        futureDate = cal.getTime();

        // A second future date for additional tests -- 60 days from today
        Calendar cal2 = Calendar.getInstance();
        cal2.add(Calendar.DAY_OF_YEAR, 60);
        farFutureDate = cal2.getTime();

        service = new AppointmentService();
        appointment = new Appointment(VALID_ID, futureDate, VALID_DESCRIPTION);
        service.addAppointment(appointment);
    }

    // ── Add Appointment Tests ─────────────────────────────────────

    @Test
    void testAddAppointment_withValidAppointment_appointmentExistsInService() {
        Appointment newAppointment = new Appointment("APPT000002", farFutureDate, "Follow up visit with specialist");
        service.addAppointment(newAppointment);
        assertEquals(newAppointment, service.getAppointment("APPT000002"));
    }

    @Test
    void testAddAppointment_withDuplicateId_throwsException() {
        Appointment duplicate = new Appointment(VALID_ID, futureDate, "Duplicate appointment entry");
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(duplicate));
    }

    @Test
    void testAddAppointment_withNullAppointment_throwsException() {
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(null));
    }

    // ── Delete Appointment Tests ──────────────────────────────────

    @Test
    void testDeleteAppointment_withValidId_appointmentIsNull() {
        service.deleteAppointment(VALID_ID);
        assertNull(service.getAppointment(VALID_ID));
    }

    @Test
    void testDeleteAppointment_withNonExistentId_throwsException() {
        assertThrows(IllegalArgumentException.class, () ->
            service.deleteAppointment("DOES_NOT_EXIST"));
    }

    // ── Get Appointment Tests ─────────────────────────────────────

    @Test
    void testGetAppointment_withNonExistentId_returnsNull() {
        assertNull(service.getAppointment("DOES_NOT_EXIST"));
    }
}
