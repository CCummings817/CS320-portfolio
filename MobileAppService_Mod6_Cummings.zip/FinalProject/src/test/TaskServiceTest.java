package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import main.java.model.Task;
import main.java.service.TaskService;

public class TaskServiceTest {

    private static final String VALID_ID = "TASK000001";
    private static final String VALID_NAME = "Buy Groceries";
    private static final String VALID_DESCRIPTION = "Pick up items from the store";

    private TaskService service;
    private Task task;

    @BeforeEach
    void setUp() {
        service = new TaskService();
        task = new Task(VALID_ID, VALID_NAME, VALID_DESCRIPTION);
        service.addTask(task);
    }

    // ── Add Task Tests ────────────────────────────────────────────

    @Test
    void testAddTask_withValidTask_taskExistsInService() {
        Task newTask = new Task("TASK000002", "Do Laundry", "Wash and fold all clothes");
        service.addTask(newTask);
        assertEquals(newTask, service.getTask("TASK000002"));
    }

    @Test
    void testAddTask_withDuplicateId_throwsException() {
        Task duplicate = new Task(VALID_ID, "Duplicate", "This ID already exists in service");
        assertThrows(IllegalArgumentException.class, () -> service.addTask(duplicate));
    }

    @Test
    void testAddTask_withNullTask_throwsException() {
        assertThrows(IllegalArgumentException.class, () -> service.addTask(null));
    }

    // ── Delete Task Tests ─────────────────────────────────────────

    @Test
    void testDeleteTask_withValidId_taskIsNull() {
        service.deleteTask(VALID_ID);
        assertNull(service.getTask(VALID_ID));
    }

    @Test
    void testDeleteTask_withNonExistentId_throwsException() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("DOES_NOT_EXIST"));
    }

    // ── Update Task Tests ─────────────────────────────────────────

    @Test
    void testUpdateTask_withValidTask_taskReflectsUpdates() {
        Task updatedTask = new Task(VALID_ID, "Updated Name", "Updated description for the task item");
        service.updateTask(VALID_ID, updatedTask);
        Task result = service.getTask(VALID_ID);
        Task expected = new Task(VALID_ID, "Updated Name", "Updated description for the task item");
        assertEquals(expected, result);
    }

    @Test
    void testUpdateTask_withNullTask_throwsException() {
        assertThrows(IllegalArgumentException.class, () ->
            service.updateTask(VALID_ID, null));
    }

    @Test
    void testUpdateTask_withNullName_throwsException() {
        assertThrows(IllegalArgumentException.class, () ->
            service.updateTask(VALID_ID, new Task(VALID_ID, null, VALID_DESCRIPTION)));
    }

    @Test
    void testUpdateTask_withNameTooLong_throwsException() {
        assertThrows(IllegalArgumentException.class, () ->
            service.updateTask(VALID_ID,
                new Task(VALID_ID, "This Name Is Way Too Long For The Field", VALID_DESCRIPTION)));
    }

    @Test
    void testUpdateTask_withNullDescription_throwsException() {
        assertThrows(IllegalArgumentException.class, () ->
            service.updateTask(VALID_ID, new Task(VALID_ID, VALID_NAME, null)));
    }

    @Test
    void testUpdateTask_withDescriptionTooLong_throwsException() {
        assertThrows(IllegalArgumentException.class, () ->
            service.updateTask(VALID_ID, new Task(VALID_ID, VALID_NAME,
                "This description is far too long and exceeds the fifty character limit set by requirements")));
    }

    @Test
    void testUpdateTask_withNonExistentId_throwsException() {
        Task updatedTask = new Task(VALID_ID, VALID_NAME, VALID_DESCRIPTION);
        assertThrows(IllegalArgumentException.class, () ->
            service.updateTask("DOES_NOT_EXIST", updatedTask));
    }

    // ── Get Task Tests ────────────────────────────────────────────

    @Test
    void testGetTask_withNonExistentId_returnsNull() {
        assertNull(service.getTask("DOES_NOT_EXIST"));
    }
}
