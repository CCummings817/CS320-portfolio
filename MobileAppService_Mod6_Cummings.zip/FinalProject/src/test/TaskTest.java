package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import main.java.model.Task;

public class TaskTest {

    private static final String VALID_ID = "TASK000001";
    private static final String VALID_NAME = "Buy Groceries";
    private static final String VALID_DESCRIPTION = "Pick up items from the store";

    private Task task;

    @BeforeEach
    void setUp() {
        task = new Task(VALID_ID, VALID_NAME, VALID_DESCRIPTION);
    }

    // ── Task ID Tests ─────────────────────────────────────────────

    @Test
    void testTaskId_withValidId_isStored() {
        assertEquals(VALID_ID, task.getTaskId());
    }

    @Test
    void testTaskId_withNullId_throwsException() {
        assertThrows(IllegalArgumentException.class, () ->
            new Task(null, VALID_NAME, VALID_DESCRIPTION));
    }

    @Test
    void testTaskId_withIdTooLong_throwsException() {
        assertThrows(IllegalArgumentException.class, () ->
            new Task("12345678901", VALID_NAME, VALID_DESCRIPTION));
    }

    @Test
    void testTaskId_isNotUpdatable_remainsUnchanged() {
        // taskId is final -- no setter exists, verified by design
        assertEquals(VALID_ID, task.getTaskId());
    }

    // ── Name Tests ────────────────────────────────────────────────

    @Test
    void testName_withValidName_isStored() {
        assertEquals(VALID_NAME, task.getName());
    }

    @Test
    void testName_withNullName_throwsException() {
        assertThrows(IllegalArgumentException.class, () ->
            new Task(VALID_ID, null, VALID_DESCRIPTION));
    }

    @Test
    void testName_withNameTooLong_throwsException() {
        assertThrows(IllegalArgumentException.class, () ->
            new Task(VALID_ID, "This Name Is Way Too Long For The Field", VALID_DESCRIPTION));
    }

    @Test
    void testName_withUpdatedName_isStored() {
        task.setName("Updated Name");
        assertEquals("Updated Name", task.getName());
    }

    @Test
    void testName_withNullUpdate_throwsException() {
        assertThrows(IllegalArgumentException.class, () -> task.setName(null));
    }

    @Test
    void testName_withUpdateTooLong_throwsException() {
        assertThrows(IllegalArgumentException.class, () ->
            task.setName("This Name Is Way Too Long For The Field"));
    }

    // ── Description Tests ─────────────────────────────────────────

    @Test
    void testDescription_withValidDescription_isStored() {
        assertEquals(VALID_DESCRIPTION, task.getDescription());
    }

    @Test
    void testDescription_withNullDescription_throwsException() {
        assertThrows(IllegalArgumentException.class, () ->
            new Task(VALID_ID, VALID_NAME, null));
    }

    @Test
    void testDescription_withDescriptionTooLong_throwsException() {
        assertThrows(IllegalArgumentException.class, () ->
            new Task(VALID_ID, VALID_NAME, "This description is far too long and exceeds the fifty character limit set by requirements"));
    }

    @Test
    void testDescription_withUpdatedDescription_isStored() {
        task.setDescription("Updated description text");
        assertEquals("Updated description text", task.getDescription());
    }

    @Test
    void testDescription_withNullUpdate_throwsException() {
        assertThrows(IllegalArgumentException.class, () -> task.setDescription(null));
    }

    @Test
    void testDescription_withUpdateTooLong_throwsException() {
        assertThrows(IllegalArgumentException.class, () ->
            task.setDescription("This description is far too long and exceeds the fifty character limit set by requirements"));
    }

    // ── Equals Tests ──────────────────────────────────────────────

    @Test
    void testEquals_withIdenticalTask_returnsTrue() {
        Task other = new Task(VALID_ID, VALID_NAME, VALID_DESCRIPTION);
        assertEquals(task, other);
    }

    @Test
    void testEquals_withDifferentTask_returnsFalse() {
        Task other = new Task("TASK000002", VALID_NAME, VALID_DESCRIPTION);
        assertNotEquals(task, other);
    }
}
