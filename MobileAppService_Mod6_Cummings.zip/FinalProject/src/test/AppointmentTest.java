package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import main.java.model.Appointment;

import java.util.Calendar;
import java.util.Date;

public class AppointmentTest {

    private static final String VALID_ID = "APPT000001";
    private static final String VALID_DESCRIPTION = "Annual checkup with primary care doctor";

    private Date futureDate;
    private Date farFutureDate;
    private Appointment appointment;

    @BeforeEach
    void setUp() {
        // Always 30 days from today -- never stale
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, 30);
        futureDate = cal.getTime();

        // A second future date for update tests -- 60 days from today
        Calendar cal2 = Calendar.getInstance();
        cal2.add(Calendar.DAY_OF_YEAR, 60);
        farFutureDate = cal2.getTime();

        appointment = new Appointment(VALID_ID, futureDate, VALID_DESCRIPTION);
    }

    // ── Appointment ID Tests ──────────────────────────────────────

    @Test
    void testAppointmentId_withValidId_isStored() {
        assertEquals(VALID_ID, appointment.getAppointmentId());
    }

    @Test
    void testAppointmentId_withNullId_throwsException() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment(null, futureDate, VALID_DESCRIPTION));
    }

    @Test
    void testAppointmentId_withIdTooLong_throwsException() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("12345678901", futureDate, VALID_DESCRIPTION));
    }

    @Test
    void testAppointmentId_isNotUpdatable_remainsUnchanged() {
        // appointmentId is final -- no setter exists, verified by design
        assertEquals(VALID_ID, appointment.getAppointmentId());
    }

    // ── Appointment Date Tests ────────────────────────────────────

    @Test
    void testAppointmentDate_withFutureDate_isStored() {
        assertNotNull(appointment.getAppointmentDate());
    }

    @Test
    void testAppointmentDate_withNullDate_throwsException() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment(VALID_ID, null, VALID_DESCRIPTION));
    }

    @Test
    void testAppointmentDate_withPastDate_throwsException() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -1);
        Date pastDate = cal.getTime();
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment(VALID_ID, pastDate, VALID_DESCRIPTION));
    }

    @Test
    void testAppointmentDate_withUpdatedFutureDate_isStored() {
        appointment.setAppointmentDate(farFutureDate);
        assertNotNull(appointment.getAppointmentDate());
    }

    @Test
    void testAppointmentDate_withNullUpdate_throwsException() {
        assertThrows(IllegalArgumentException.class, () ->
            appointment.setAppointmentDate(null));
    }

    @Test
    void testAppointmentDate_withPastDateUpdate_throwsException() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -1);
        Date pastDate = cal.getTime();
        assertThrows(IllegalArgumentException.class, () ->
            appointment.setAppointmentDate(pastDate));
    }

    // ── Description Tests ─────────────────────────────────────────

    @Test
    void testDescription_withValidDescription_isStored() {
        assertEquals(VALID_DESCRIPTION, appointment.getDescription());
    }

    @Test
    void testDescription_withNullDescription_throwsException() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment(VALID_ID, futureDate, null));
    }

    @Test
    void testDescription_withDescriptionTooLong_throwsException() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment(VALID_ID, futureDate,
                "This description is far too long and exceeds the fifty character limit set by requirements"));
    }

    @Test
    void testDescription_withUpdatedDescription_isStored() {
        appointment.setDescription("Updated appointment description text");
        assertEquals("Updated appointment description text", appointment.getDescription());
    }

    @Test
    void testDescription_withNullUpdate_throwsException() {
        assertThrows(IllegalArgumentException.class, () ->
            appointment.setDescription(null));
    }

    @Test
    void testDescription_withUpdateTooLong_throwsException() {
        assertThrows(IllegalArgumentException.class, () ->
            appointment.setDescription(
                "This description is far too long and exceeds the fifty character limit set by requirements"));
    }

    // ── Equals Tests ──────────────────────────────────────────────

    @Test
    void testEquals_withIdenticalAppointment_returnsTrue() {
        Appointment other = new Appointment(VALID_ID, futureDate, VALID_DESCRIPTION);
        assertEquals(appointment, other);
    }

    @Test
    void testEquals_withDifferentAppointment_returnsFalse() {
        Appointment other = new Appointment("APPT000002", futureDate, VALID_DESCRIPTION);
        assertNotEquals(appointment, other);
    }
}
