package main.java.service;

import main.java.model.Task;

import java.util.HashMap;
import java.util.Map;

public class TaskService {

    private final Map<String, Task> tasks = new HashMap<>();

    public void addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null");
        }
        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task ID already exists");
        }
        tasks.put(task.getTaskId(), task);
    }

    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found");
        }
        tasks.remove(taskId);
    }

    public void updateTask(String taskId, Task updatedTask) {
        if (updatedTask == null) {
            throw new IllegalArgumentException("Updated task cannot be null");
        }
        Task task = getTaskOrThrow(taskId);
        task.setName(updatedTask.getName());
        task.setDescription(updatedTask.getDescription());
    }

    public Task getTask(String taskId) {
        Task task = tasks.get(taskId);
        if (task == null) {
            return null;
        }
        return new Task(task.getTaskId(), task.getName(), task.getDescription());
    }

    private Task getTaskOrThrow(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found");
        }
        return tasks.get(taskId);
    }
}
